import { useState } from 'react';

export default function AnalyzePage() {
  const [text, setText] = useState('');
  const [result, setResult] = useState('');

  async function analyze() {
    const res = await fetch('/api/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });
    const data = await res.json();
    setResult(data.result);
  }

  return (
    <div>
      <h2 className="text-xl mb-2">계약서 자동 분석</h2>
      <textarea className="border w-full p-2 h-40" placeholder="계약서 텍스트 입력" value={text} onChange={e => setText(e.target.value)}></textarea>
      <button className="bg-red-500 text-white px-2 py-1 mt-2" onClick={analyze}>위험 문구 표시</button>
      <pre className="bg-gray-100 p-2 mt-2">{result}</pre>
    </div>
  );
}
