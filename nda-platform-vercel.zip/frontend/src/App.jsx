import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import NdaPage from './pages/NdaPage';
import TransactionPage from './pages/TransactionPage';
import FilePage from './pages/FilePage';
import CertPage from './pages/CertPage';
import AnalyzePage from './pages/AnalyzePage';
import TimelinePage from './pages/TimelinePage';
import SimulationPage from './pages/SimulationPage';

function App() {
  return (
    <Router>
      <div className="p-4">
        <nav className="mb-4 flex gap-4 flex-wrap">
          <Link to="/nda" className="text-blue-500">계약 관리</Link>
          <Link to="/transaction" className="text-blue-500">거래 기록</Link>
          <Link to="/file" className="text-blue-500">파일 업로드</Link>
          <Link to="/cert" className="text-blue-500">증명서 발행</Link>
          <Link to="/analyze" className="text-blue-500">계약서 분석</Link>
          <Link to="/timeline" className="text-blue-500">거래 타임라인</Link>
          <Link to="/simulation" className="text-blue-500">모의소송</Link>
        </nav>
        <Routes>
          <Route path="/nda" element={<NdaPage />} />
          <Route path="/transaction" element={<TransactionPage />} />
          <Route path="/file" element={<FilePage />} />
          <Route path="/cert" element={<CertPage />} />
          <Route path="/analyze" element={<AnalyzePage />} />
          <Route path="/timeline" element={<TimelinePage />} />
          <Route path="/simulation" element={<SimulationPage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
