export default function handler(req, res) {
  const { text } = req.body || {};
  const risky = text?.includes('독점') ? '독점 금지 위반 가능성 있음' : '문제 없음';
  res.status(200).json({ result: risky });
}
